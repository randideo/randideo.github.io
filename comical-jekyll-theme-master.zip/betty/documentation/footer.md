---
layout: page
title: "footer"
permalink: /documentation/footer.html
---
I like my footers to stay on the bottom of the page no matter what. You can easily edit the size and color using the supplied sass variables.