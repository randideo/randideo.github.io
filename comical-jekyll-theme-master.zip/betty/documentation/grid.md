---
layout: page
title: "grid"
permalink: /documentation/grid.html
---

Uses minimal sass from Zurb Foundation 6: 

* [grid](http://foundation.zurb.com/sites/docs/grid.html)
* [visibility](http://foundation.zurb.com/sites/docs/visibility.html)
* [media query](http://foundation.zurb.com/sites/docs/media-queries.html)
